<?php

$id_akun=[
29541, //id akun satu
38150, //id akun dua
38148
29772,
30137,
29783,
30869,
30871,
30874,
30876,
30878,
30884,
37524,
37541,
38154,
38153,
39158,
39178,
39181,
39180,
];
$email_login=[
"fevernaya@gmail.com", //email akun satu
"wallercarolina550@gmail.com", //email akun dua
"andisianturie@gmail.com",
"gaizmania25@gmail.com",
"almerbarokah@gmail.com",
"jimmybozka@gmail.com",
"ahmedhabibie3@gmail.com",
"analontong45@gmail.com",
"solehimoets@gmail.com",
"imotkuceng@gmail.com",
"vitamania93@gmail.com",
"arthurgantenge@gmail.com",
"legendzanis@gmail.com",
"valheinfast@gmail.com",
"edwardweaver212@gmail.com",
"laurawilson739@gmail.com",
"lilianacutez@gmail.com",
"sambelbledex@gmail.com",
"hariyantoepo231@gmail.com",
"samsurie788@gmail.com",
];
