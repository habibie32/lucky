<?

$UserAgent = "Mozilla/5.0 (Linux; Android 6.0; Infinix-X600-LTE) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.96 Mobile Safari/537.36";
$Email = "evel=fevernaya%40gmail.com";
$Password = "vina210493";

//Masukkan Cookie -> cf_clearance atau PHPSESSID
$Cookie = "PHPSESSID=7urrprjt12camvbdmkaa8qm9s4";